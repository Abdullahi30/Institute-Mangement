package com.alixumer.schoolapp.brain_school;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
